


export default function UCatolica(){
    <div className="container">
        <section className="layer" id="layer-mir-topics">
          <nav className="layer-nav">
            <ul id="mir-list" className="max-width-500">
            </ul>
            <br /><br />
          </nav>
        </section>
    </div>
}