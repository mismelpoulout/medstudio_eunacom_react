const quizQuestions = [


{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
},
{
    "question": "",
    "options": [
        "", "", "", "", ""
    ],
    "answer": "",
    "imgs": "recursos/diciembre 2019/.png",
    "feedback": ""
}
]
