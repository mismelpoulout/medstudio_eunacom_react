import firebase from "firebase/compat/app";
import "firebase/compat/auth";

export const app = firebase.initializeApp({
  apiKey: "AIzaSyA_tkdZnjSO8tV1_o_LtwQUR_26i2vKXG4",
  authDomain: "eunacom-chile.firebaseapp.com",
  projectId: "eunacom-chile",
  storageBucket: "eunacom-chile.appspot.com",
  messagingSenderId: "109229401681",
  appId: "1:109229401681:web:907628d4a3ed67eda4fa70",
  measurementId: "G-G4ZW1JC0Q0"
});
